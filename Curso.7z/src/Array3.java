public class Array3 {

	public static void main(String[] args) {
		
		// Arrays multidimensionales
		
		int[][] matrix = new int[4][4];
		int a = 10;
		int b = 1;
		for (int i = 0; i<4; i++){
			
			for (int j = 0; j<4; j++){
				
				matrix[i][j]= a+b;			
				b++;
				
			}
			a = a + 10;
			b = 1;
		}
		
		for (int i = 0; i<4; i++){

			for (int j = 0; j<4; j++){

				System.out.printf(matrix[i][j] + " | ");			
				
			}
			
			System.out.println();
			
		}

	}

}
