
public class Bucles3 {

	public static void main(String[] args) {
		
		// mientras que el while eval�a la condici�n antes de ejecutar,
		// el do while ejecuta al menos una vez el bloque de instrucciones y luego eval�a
		
		int a = 10;
		int i = 0;
		do {
			a++;
			i++;
		}
		while (a < 10);
		System.out.println("Pas� " + i + " veces por el bloque de instrucciones");
		System.out.println("El valor a vale " + a);
		
		int b = 10;
		int j = 0;
		while (b < 10) {
			b++;
			j++;
		}
		System.out.println("Pas� " + j + " veces por el bloque de instrucciones");
		System.out.println("El valor b vale " + b);
		
	}

}
