
public class Cadenas {

	public static void main(String[] args) {
		
		/* Clase String que al instanciarla la volveremos un objeto
		 * Es una clase al igual que Math, con lo cual... se puede
		 * poner String.[m�todos] y elegir alguno de la lista
		 *  
		 */

		
		String word = "qwertyuiop";
		
		System.out.println(word.charAt(6));
		System.out.println(word.length());
		System.out.println(word.substring(1, 4));
		System.out.println(word.endsWith("d"));
		System.out.println(word.equals("qwertyuioP"));
		System.out.println(word.equalsIgnoreCase("qwertyuioP"));
		
				
		

	}

}
