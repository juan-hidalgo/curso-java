
public class Array2 {

	public static void main(String[] args) {

		// Uso del for com�n para llenar un array
		
		int[] matrix = new int[10];
		
		for (int i = 0; i < matrix.length; i++) {
		
			matrix[i]=(int)(Math.random()*10);
					
		}

		// Uso del "for each" para recorrer arrays. Ac� para mostrar los elementos
		
		for (int elemento : matrix) {
		
			System.out.print(elemento + " | ");
		
		}
		
		
	}

}