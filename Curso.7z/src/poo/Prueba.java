package poo;

// Utilizaci�n de campos y m�todos est�ticos

public class Prueba {

	public static void main(String[] args) {
		Empleados trabajador1 = new Empleados("Mike");	//�Piensa Mike, eres el l�der!
		Empleados trabajador2 = new Empleados("Bobby");	//Bobby... �eres t�?
		System.out.println(trabajador1.getDatos());
		// trabajador2.setNombre("Rick");				// Esto no se puede hacer porque nombre es constante
		trabajador2.setSeccion("RRHH");
		System.out.println(trabajador2.getDatos());
		System.out.println("Pi es: " + Math.PI);
		
	}

}

// AC� NO SE RESPETA LA MODULARIDAD O MODULARIZACI�N

class Empleados {

	private final String nombre;
	private String seccion;

	// Constructor
	public Empleados(String nom){
		nombre=nom;
		seccion="Administraci�n";
	}

	// Setter de seccion
	public void setSeccion(String seccion){
		this.seccion = seccion;
	}
	
	// Setter de nombre
	public void setNombre(String nombre){
		this.nombre = nombre;
	}

	// Getter de nombre y seccion
	public String getDatos(){
		return nombre + " trabaja en " + seccion;

	}

}