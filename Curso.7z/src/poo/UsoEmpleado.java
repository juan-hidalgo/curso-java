package poo;

public class UsoEmpleado {

	public static void main(String[] args) {
		
		Empleado[] listaEmpleados = new Empleado[3];
		
		listaEmpleados[0] = new Empleado("Tom Glavine", 28000, 1966, 3, 25);
		listaEmpleados[1] = new Empleado("Greg Maddux", 32000, 1966, 4, 14);
		listaEmpleados[2] = new Empleado("John Smoltz", 30000, 1967, 5, 15);
		
		for (Empleado e: listaEmpleados){
			e.setSubirSueldo(5);
		}
		
		for (Empleado e: listaEmpleados){
			System.out.println("Nombre: " +	e.getNombre() + ". " +
					"Sueldo: $" + e.getSueldo() + ". " +
					"Alta: " + e.getAlta());
		}
					
	}

}
