package poo;

public class Coche {

	private int ruedas = 4; 		// cantidad (son private por ENCAPSULAMIENTO (�nicos de esta clase) 
	private int puertas; 			// cantidad
	private int largo;				// en cm
	private int ancho;				// en cm
	private int motor;				// en cm^3
	private int pesoPlataforma;		// en kg
	private int peso; 				// en kg
	private String color; 			// palabra
	private boolean asientosCuero;	// si o no
	private boolean climatizador;	// si o no

	// M�todo constructor. Mismo nombre de la clase, sirve para poner el estado inicial del objeto. 
	public Coche() {
		puertas = 4;
		largo = 510;	
		ancho = 200;	
		motor = 1800;	
		pesoPlataforma = 850; 	
	}
	// M�todo getter. Lleva "return" porque retorna siempre alg�n valor.
	public String getPuertas() {
		return ("El coche tiene " + puertas + " puertas.");
	}
	// M�todo setter de puertas
	public void setPuertas(int puertas){
		this.puertas = puertas;	
	}
	
	// M�todo getter de color. 
	public String getColor() {
		return ("El coche es de color " + color);
	}
	// M�todo setter de color. Es void porque no retorna ning�n valor.
	public void setColor(String color) {

		this.color = color;
	}
	// getter de motor (todo getter es un m�todo) 
	public String getMotor() {
		return ("El coche tiene un motor de " + motor + " cm^3");
	}
	/* setter de motor
	 * Pasaje (o paso) de par�metros.
	 */
	public void setMotor(int cilindrada) {

		motor = cilindrada;
	}
	// getter de asientos
	public String getAsientos() {
		if (asientosCuero){
			return "Tiene asientos de cuero";
		} else{
			return "Tiene asientos de tela";	
		}
	}
	/* setter de asientos
	 * �Y qu� pasa si el nombre del argumento es igual al nombre de la propiedad?
	 * Se usa el operador this que hace referencia a la clase misma. 	 
	 */
	public void setAsientos(String asientosCuero) {

		if (asientosCuero.equals("si")) { // LAS CADENAS SE COMPARAN CON EQUALS
			this.asientosCuero = true;	
		} else {
			this.asientosCuero = false;
		}
	}
	// getter de climatizador (ojo que al ser boolean cambia la convenci�n de nombre)
		public String isClimatizador() {
			if (climatizador==true) {
				return "El coche tiene climatizador";
			} else{
				return "El coche tiene aire acondicionado";
			}
		}
	// setter de climatizador
	public void setClimatizador(String climatizador) {
		if (climatizador.equals("si")){
			this.climatizador = true;
		} else{
			this.climatizador = false;
		}
	}
	
	// getter de ruedas
	public int getRuedas() {
		return ruedas;
	}
	// setter de ruedas
	public void setRuedas(int ruedas) {
		this.ruedas = ruedas;
	}
	// getter de largo
	public int getLargo() {
		return largo;
	}
	// setter de largo
	public void setLargo(int largo) {
		this.largo = largo;
	}
	// getter de ancho
	public int getAncho() {
		return ancho;
	}
	// setter de ancho
	public void setAncho(int ancho) {
		this.ancho = ancho;
	}
	// getter de pesoPlataforma
	public int getPesoPlataforma() {
		return pesoPlataforma;
	}
	// setter de pesoPlataforma
	public void setPesoPlataforma(int pesoPlataforma) {
		this.pesoPlataforma = pesoPlataforma;
	}
	// getter de peso
	public int getPeso() {
		return peso;
	}
	// setter de peso
	public void setPeso(int peso) {
		this.peso = peso;
	}


	// getter SUELTO de precio
	public int getPrecio() {
		int precio = 10000;
		
		if (asientosCuero==true){
			precio+=1000;
		}
		if (climatizador==true){
			precio+=2500;
		}
		return precio;
	}
}


