package poo;

import javax.swing.*;

public class UsoCoche {

	public static void main(String[] args) {

		/* Instanciar una clase, hacerla "ejemplar de clase") 
		 * es crear un objeto con sus datos.  
		 */ 

		Coche Coupe = new Coche();

		/* con "Coche Coupe" instanciamos a Coupe como objeto de la clase Coche
		 * con "new Coche()" llamamos al constructor para ejecutarlo
		 */

		// System.out.println("Ruedas: " + Coupe.ruedas);
		// ac� ruedas no es visible por el encapsulamiento de coche.ruedas
		// Usamos un m�todo para que se puedan ver la cantidad de ruedas

		String color = JOptionPane.showInputDialog("�De qu� color?:");
		Coupe.setColor(color);
		
		String numero = JOptionPane.showInputDialog("Ingresar cilindrada:");
		int a = Integer.parseInt(numero);
		Coupe.setMotor(a);
		String cuero = JOptionPane.showInputDialog("�Tiene asientos de cuero?:");
		Coupe.setAsientos(cuero);
		String climatizador = JOptionPane.showInputDialog("�Tiene climatizador?:");
		Coupe.setClimatizador(climatizador);
		

		System.out.println(Coupe.getPuertas());
		System.out.println(Coupe.getColor());
		System.out.println(Coupe.getMotor());
		System.out.println(Coupe.getAsientos());
		System.out.println(Coupe.isClimatizador());
		// Este es el formato correcto para manejar mensajes con getters 
		System.out.println("El precio del coche es $" + Coupe.getPrecio());
		

	}

}
