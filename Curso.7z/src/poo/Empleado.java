package poo;

import java.util.*;

public class Empleado {

	// Variables de clase
	private String nombre;
	private double sueldo;
	private Date alta;

	// Constructor
	// Nombre, sueldo, fecha de alta
	public Empleado(String nom, double sue, int anio, int mes, int dia){
		nombre=nom;
		sueldo=sue;
		GregorianCalendar calendario = new GregorianCalendar(anio, mes-1, dia);
		alta = calendario.getTime();
	}

	// Getter de nombre
	public String getNombre() {
		return nombre;
	}

	// Setter de nombre
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	// Getter de sueldo
	public double getSueldo() {
		return sueldo;
	}

	// Setter de sueldo
	public void setSueldo(double sueldo) {
		this.sueldo = sueldo;
	}

	// Getter de alta
	public Date getAlta() {
		return alta;
	}

	// Setter de alta
	public void setAlta(Date alta) {
		this.alta = alta;
	}
	
	// Setter para Subir Sueldo
	public void setSubirSueldo(double porcentaje) {
		double aumento = sueldo * porcentaje / 100;
		sueldo += aumento;
	}
	
}
