import javax.swing.*;
public class InputOutput2 {

	public static void main(String[] args) {
		
		String nombreUsuario = JOptionPane.showInputDialog("Introduce tu nombre");
		
		String edad = JOptionPane.showInputDialog("Introduce tu edad");
		
		int edadUsuario = Integer.parseInt(edad);
		
		System.out.println("Hola " + nombreUsuario + ". Cumplir�s " + (edadUsuario + 1) + " a�os.");

	}

}
