
public class DeclaracionOperadores {

	public static void main(String[] args) {
		
		int a = 5;
		
		int b;
		b = 7;
		
		int c = b + a;
		c++;
		c=c+2;
		c+=1;
		
		System.out.println(c);
		
		

	}

}
