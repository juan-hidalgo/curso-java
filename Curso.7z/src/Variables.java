
public class Variables {

	public static void main(String[] args) {
		// https://www.youtube.com/watch?v=bq6nJRJq27A

		final int constante = 8; 
		int edad = 30;
		System.out.println(edad + constante);
		edad = 40;
		System.out.println(edad + constante);
		

	}

}
