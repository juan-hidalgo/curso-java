import java.util.*;
public class Condicionales {

	public static void main(String[] args) {
		// veremos el uso de if, if else, switch & switch default
		
		Scanner entrada = new Scanner (System.in);
		
		System.out.println("Edad");
		
		//if else <- Se usa para poner dos opciones, ambas con operaciones, si no, s�lo usamos if
			
		int edad = entrada.nextInt();
		
		/*		
		if (edad >=18){
			System.out.println("Mayor de edad");
		}
		else {
			System.out.println("Menor de edad");
		}

		System.out.println("Edad");
		
		*/
		
		//if else if <- Se usa para poner varias opciones de evaluacioens incrementales
		
		// edad = entrada.nextInt();
		
		if (edad < 12){
			System.out.println("Ni�o");
		}
		else if (edad<20){
			System.out.println("Adolescente");
		}
		else if (edad<50){
			System.out.println("Adulto");
		}
		else {
			System.out.println("Maduro");
		}

		entrada.close();
	}

}
