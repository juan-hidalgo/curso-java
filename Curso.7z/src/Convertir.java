
public class Convertir {

	public static void main(String[] args) {
		
		// Const declaration
		final double CM_A_PULGADAS=2.54;
		final double CM_A_PIES=30.48;
		
		// Declaraci�n de variables
		double cm = 170;
		double pulgadas;
		double pies;
		
		// Convertir cm a pulgadas
		double resultado = cm / CM_A_PULGADAS;
		
		// Convertir cm a pies, redondeando hacia abajo al entero
		pies = cm / CM_A_PIES;
		pies = Math.floor(pies);
		
		// Convertir cm restantes a pulgadas, redondeando hacia abajo al entero 		
		pulgadas = (cm - pies * CM_A_PIES) / CM_A_PULGADAS;
		pulgadas = Math.floor(pulgadas);
		
		// Informar
		System.out.println("Altura en cm");
		System.out.println("Son " + resultado + " pulgadas");
		System.out.print("Se dice: ");
		System.out.printf("%1.0f", pies);
		System.out.print(" pies con ");
		System.out.printf("%1.0f", pulgadas);
		System.out.println(" pulgadas.");
		
		System.out.println("Tambi�n: " + Math.round(pies) + "\'" + Math.round(pulgadas) + "\"");
		

		
	}

}
