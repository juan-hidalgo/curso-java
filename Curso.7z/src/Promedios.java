import javax.swing.*;
public class Promedios {

	public static void main(String[] args) {
		
		// Ingresar cantidad de elementos
		
		int cantidad = Integer.parseInt(JOptionPane.showInputDialog("Total de valores: "));

		int[] lista = new int[cantidad];
		
		// Ingresar elementos
		
		for (int i = 0; i < lista.length; i++) {
		
			int valor = Integer.parseInt(JOptionPane.showInputDialog("Valor " + i + " :"));
			lista[i] = valor;
			
		}
		
		// sumar elementos
		
		int total = 0;
		
		for (int j = 0; j < lista.length; j++) {
			
			total = total + lista[j];
			
		}
		
		// calcular promedio
		
		
		double totalx = (double) total;
		double promedio = (totalx / lista.length);
		System.out.println("El total es: " + total);
		System.out.println("La cantidad de elementos es: " + lista.length);
		System.out.print("El promedio es: ");
		System.out.printf("%.2f", promedio);
		
		
	}

}
