//import java.util.*;
//
//public class PruebaPaquetes {
//
//	public static void main(String[] args) {
//
//		String nombre;
//
//		/* Scanner es una clase del paquete java.util (en lugar de java.lang que es el default)
//		 * Usamos fuera de la declaraci�n de clase, el "import", para decir que traemos todas las clases
//		 * del paquete "util".
//		 * 
//		 */
//
//		Scanner objetoprueba;
//
//	}
//
//}
