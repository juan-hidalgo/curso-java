import java.util.*;

public class Bucles2 {

	public static void main(String[] args) {
		
		// Atenci�n al modo de pasar un double a int  
		
		int a = (int)(Math.round(Math.random()*100));
				
		Scanner entrada = new Scanner(System.in);
		
		int numero = 0;
		int intentos = 0;
		
		System.out.println("�Qu� n�mero ser�?");
		
		while (numero != a){
			
			numero = entrada.nextInt();
						
			if ((a + 20) < numero){
				System.out.println("mucho m�s bajo...");
			}
			
			else if (a + 7 < numero){
				System.out.println("m�s bajo...");
			}
			
			else if (a < numero){
				System.out.println("m�s bajo (est�s cerca)...");
			}
			
			else if (a - 20 > numero){
				System.out.println("mucho m�s alto...");
			}
			
			else if (a - 7 > numero){
				System.out.println("m�s alto...");
			}
			
			else if (a > numero){
				System.out.println("m�s alto (est�s cerca)...");
			}
			
			intentos++;
		}
		
		String titulo="";
		
		if (intentos < 4){
			titulo = "Gur� de las artes adivinatorias";
		}
		else if (intentos < 6){
			titulo = "�guila de las monta�as subtropicales";
		}
		else if (intentos < 8){
			titulo = "Maquinola interestelar";
		} 
		else {
			titulo = "Hey";
		} 
		System.out.print("�" + titulo + "! ");
		
		String palabra = "";
		
		if (intentos == 1) {
			palabra = " intento";
		}
		else {
			palabra = " intentos";
		}
		
		System.out.println("�Adivinaste el n�mero " + numero + " en " + intentos + palabra + "!");
		
		entrada.close();
	}

}
