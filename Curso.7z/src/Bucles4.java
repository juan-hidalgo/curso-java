import javax.swing.JOptionPane;

public class Bucles4 {

	public static void main(String[] args) {
		
		//bucles determinados for
		
		String palabra = "frutilla";
				
		for (int i=0; i < palabra.length(); i++) {
			
			//System.out.println(i);
			System.out.println(palabra.charAt(i));
			
		}
		
		// c�lculo de un factorial
		
		int numero = Integer.parseInt(JOptionPane.showInputDialog("N�mero a calcular el factorial:"));
		Long factorial = 1L;
		for (int j = numero; j > 0 ; j--){
			factorial = j * factorial;
		}
		System.out.println("El factorial de " + numero + " es " + factorial);
		
	}

}
