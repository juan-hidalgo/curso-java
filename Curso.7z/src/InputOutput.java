import java.util.*;

public class InputOutput {

	public static void main(String[] args) {
		
		//abrimos el scanner
		Scanner entrada = new Scanner (System.in);
		
		//ingresamos valores
		System.out.println("Ingresar palabra");
		
		String a = entrada.nextLine();
		
		System.out.println("Ingresar valor");
		
		int b = entrada.nextInt();
		
		System.out.println("Palabra: " + a + ". Valor: " + b + ".");
		
		//cerrar el scanner
		entrada.close();
		
	}

}
