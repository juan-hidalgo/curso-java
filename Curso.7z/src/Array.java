
public class Array {

	public static void main(String[] args) {
		// Arrays, matrices and such...
		
		// Ejemplo de llenado:  int[] matrix = {1,2,4,6};
		// Ejemplo de llenado por �ndice:  int[1] matrix = 2;
		// Ejemplo de llenado con un for:
		
		int[] matrix = new int[6];
		for (int i = 0; i < matrix.length; i++){
			
			matrix[i] = i * i;
			System.out.println(i + "  " + matrix[i]);
		
		}
		
		
		
		
	}

}
