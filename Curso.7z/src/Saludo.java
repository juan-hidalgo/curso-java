
public class Saludo {

	public static void main(String args[]){

		int edad = 37;
		System.out.println("Hola, tengo " + edad + " a�os");
	}
}

/*  public is an access modifier
 *  every java program must be inside a class at least
 * 	every java class name is CamelCased
 *  
 *  */

