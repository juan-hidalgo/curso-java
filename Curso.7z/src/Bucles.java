import javax.swing.*;
public class Bucles {

	public static void main(String[] args) {
		
		/* 
		 * Bucles indeterminados (while, do while)
		 * Bucles determinados (for, for each)
		 * 
		 */
		
		int a = 1;
		int b = 2; 
		
		while(a<b){
			System.out.println("L�nea " + a);
			a++;
		}
		
		String nombre = "Juan";
		String clave ="";
		
		while (clave.equals(nombre)==false){
			
			clave = JOptionPane.showInputDialog("Clave?");
			
			if (clave.equals(nombre)==false){
				System.out.println("No es correcto");
			}
			
		}
		

		System.out.println("Clave correcta");
		


	}

}
